<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Principal extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		//$this->load->model('Productos_model');
		//$this->load->model('Rutas_web_model');
		//$this->load->helper("botones_menu_principal");
		//$this->load->helper("encabezado_pagina");
		//$this->load->helper("contents");
	   
	
	}
	public function index(){
		$this->output->cache(1);		
		$this->rutas('index');
	}
	
	public function rutas($a){
	   $pagina = "index";
	   $titulo = "";

		switch ($a) {
			case 'Principal':
			  $a = $pagina;	
			  $titulo = "Inicio";
			  
				break;
			case 'index':
				
				  $titulo = "Inicio";
				break;
			case 'program':
			
			  $titulo = "Programa";
			break;
			case 'coaches':
			
			  $titulo = "Entrenadores";
			break;
			case 'schedule':
			
			  $titulo = "Programar";
			break;
			case 'about':
			
			  $titulo = "Acerca de";
			break;
			case 'blog':
			
			  $titulo = "Revista";
			break;
			case 'blog-single':
			
			  $titulo = "blog unico";

			break;
			case 'contact':
			
			  $titulo = "Contacto";
			  
			break;
		}
		
		
		$datos_blogrecientes =  array(
				
			0=>array('foto_url'=> 'assets/images/image_1.jpg',
							 'publicado_por' => array('usuario'=> 'admin', 'icon'=> 'icon-person'),
							 'fecha_publicacion' =>	 array('fecha'=>'23 de Diciembre, 2019', 'icon'=>'icon-calendar'),	
							 'num_comentarios'=> array('cantidad'=>'3', 'icon'=> 'icon-chat'),
							 'titulo_art'=> 'Mujeres jóvenes haciendo abdominales',
							 'descripcion_art'=> 'Ya desde el comienzo sabíamos que sería algo difícil, pero no por ello imposible. No obstante, realizar abdominales durante horas y meses de los meses no te dará resultado alguno si no prestas atención a un solo factor: el..',			
							 'url_articulo'=> 'blog-single'
							 
			),
			1=>array('foto_url'=> 'assets/images/bg_3.jpg',
							 'publicado_por' => array('usuario'=> 'admin', 'icon'=> 'icon-person'),
							 'fecha_publicacion' =>	 array('fecha'=>'17 de Diciembre del 2019', 'icon'=>'icon-calendar'),	
							 'num_comentarios'=> array('cantidad'=>'5', 'icon'=> 'icon-chat'),
							 'titulo_art'=> 'Beneficios de gap',
							 'descripcion_art'=> 'Te contamos los beneficios del GAP para el acondicionamiento físico',			
							 'url_articulo'=> 'blog-single',
							 
			),
			2=>array('foto_url'=> 'assets/images/image_4.jpg',
							'publicado_por' => array('usuario'=> 'admin', 'icon'=> 'icon-person'),				 
							'fecha_publicacion' =>	 array('fecha'=>'15 Enero del 2019', 'icon'=>'icon-calendar'),	
							'num_comentarios'=> array('cantidad'=>'4', 'icon'=> 'icon-chat'),
							'titulo_art'=> '9 Ejercicios diarios efectivos para mujeres después de los 40',
							'descripcion_art'=> 'El comienzo de la edad madura es un punto crítico en la vida de toda mujer. Según Ken Fox, profesor de ejercicio y ciencias de la salud en la Universidad de Bristol, es a mediados de los 40 cuando la masa muscular comienza a disminuir y..',			
							'url_articulo'=> 'blog-single'
			),
			3=>array('foto_url'=> 'assets/images/image_5.jpg',
							'publicado_por' => array('usuario'=> 'admin', 'icon'=> 'icon-person'),				 
							'fecha_publicacion' =>	 array('fecha'=>'2 de mayo del 2019', 'icon'=>'icon-calendar'),	
							'num_comentarios'=> array('cantidad'=>'3', 'icon'=> 'icon-chat'),
			     			'titulo_art'=> '20 BENEFICIOS Y VENTAJAS DE TONIFICAR TU CUERPO',
							'descripcion_art'=> 'El tono muscular viene a ser como la tensión de nuestra musculatura, una contracción involuntaria de nuestro sistema muscular',			
							'url_articulo'=> 'blog-single'
			),
		);
		$datosfooter = array(
			'blogsrecientes'=> $datos_blogrecientes,
			'autor'=> array('url'=>'https://www.facebook.com/masterbv22', 'email'=>'victor2283@gmail.com', 'nombre'=>'Victor Benitez'),
			'servicios'=>array('titulo'=> 'Servicios', 
								'items'=> array('Alza tu cuerpo',
												'Logra tu meta',
												'Analiza tu meta','Mejora tu rendimiento'),
								),
			'consultas'=>array( 'titulo'=> '¿Tienes alguna consulta?',
								'listado' => array(0 => array(
									'tipo'=> 'email',
								   'dato_mostrar'=> 'gymly2015@gmail.com',
									'icon'=> 'icon-envelope',
									'url'=> 'mailto:gymly2015@gmail.com',
						 ), 
				  1=> array(
									  'tipo'=> 'direccion',
									 'dato_mostrar'=> 'Avenida Maipú 1522 primer piso, Corrientes Capital, Argentina',
									 'icon'=> 'icon-map-marker',
									 'url'=> '#',	
						 ),
				  2=> array( 
									  'tipo'=> 'telefono',
									 'dato_mostrar'=> '+549 3794 233633',
									 'icon'=> 'icon icon-phone',
									 'url'=> '#',
						 ),),	
								 
							), 
			'about_us'=> array('titulo'=> 'sobre nosotros',
												 'descripcion'=> 'Gym enfocado a GAP, es una modalidad del fitness cuyas siglas significan Glúteos, Abdominales y Piernas. Practicar GAP sirve para fortalecer y tonificar esas tres partes del cuerpo, muy sufridas por la vida sedentaria, y que mucha gente quiere mejorar, sobre todo, las mujeres.'),
			
			'contacto' => array(
									0=> array(
										'tipo_contacto'=> 'instangram',
										'nombre'=> '@enforma_gym', 
										'url'=> 'https://www.instagram.com/enforma__gym/',
										'icon'=> 'icon-instagram'
											),
									1=> array(
										'tipo_contacto'=> 'facebook',
										'nombre'=> 'Liliana Rodriguez',
		        						'url'=> 'https://www.facebook.com/profile.php?id=100011440031647',
										'icon'=> 'icon-facebook'
											),
									2=> array(
										'tipo_contacto'=> 'twitter',
										'nombre'=> 'Liliana Rodriguez',
										'url'=> '#',
										'icon'=> 'icon-twitter'
											),				
									
									),
			   
			 
			
			
			'dato_script' => array(
				
				"assets/js/jquery.min.js",
									"assets/js/arriba.js",
									"assets/js/jquery-migrate-3.0.1.min.js",
									"assets/js/popper.min.js",
									"assets/js/bootstrap.min.js",
									"assets/js/jquery.easing.1.3.js",
									"assets/js/jquery.waypoints.min.js",
									"assets/js/jquery.stellar.min.js",
									"assets/js/owl.carousel.min.js",
									"assets/js/jquery.magnific-popup.min.js",
									"assets/js/aos.js",
									"assets/js/jquery.animateNumber.min.js",
									"assets/js/bootstrap-datepicker.js",
									"assets/js/jquery.timepicker.min.js",
									"assets/js/scrollax.min.js",
									"https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false",
									"assets/js/google-map.js",
									"assets/js/main.js",
									)

			   
			);
			$datos_section_counter= array(


			);
			$datos_section_about= array();
			$datos_section_services = array('section_services'=> array(
				'url_img'=> 'assets/images/about.jpg',
				'titulo'=> 'Da forma a tu cuerpo',
				'subtitulo'=>'¿Qué hacemos?',
				'puntos_claves'=> array(
						0=> array(
							'titulo' => 'Analiza tu meta',
							'descripcion' => 'Realiza una medición de tú cuerpo y mentaliza las medidas que tendrás después de un periodo de entrenamiento.',
							'icono' => 'flaticon-ruler'

						),
						1=> array(
							'titulo' => 'Trabajar duro en ello',
							'descripcion' => 'Las mejores cosas se logran con perseverancia y esfuerzo, no te rindas, da un paso a la vez hasta llegar a la meta.',
							'icono' => 'flaticon-gym'

						),
						2=> array(
							'titulo' => 'Mejora tu rendimiento',
							'descripcion' => 'Ten en cuenta que las personas que hacen una vida saludable disfrutan más de las pequeñas cosas de la vida, viven con energía,  concentración,  y mucho entusiasmo para afrontar cualquier actividad.',
							'icono' => 'flaticon-tools-and-utensils'

						),
						3=> array(
							'titulo' => 'Consigue tu cuerpo perfecto',
							'descripcion' => 'Aunque el cuerpo perfecto es utopía con nuestro entrenamiento realizado en forma constante veras un cambio real tanto en tu forma física y en tu mentalidad a la hora de proponerse alcanzar un objetivo.',
							'icono' => 'flaticon-abs'

						),
									)

						 ));
				$datos_testimony = array('exito_testimonio'=>array(
					0=> array('testimonio'=> 'Mi experiencia con ellos fue muy buena, conseguí muy buenos resultados, de hecho los podéis ver en las fotos aquí mismo. Magnífico trato muy atentos en todo y formalidad, cosa que al menos yo valoro mucho en un profesional.',
										'foto'=> 'assets/images/person_2.jpg',
										'nombre'=> 'Belinda Norton Smith',
										'ocupacion'=> 'Cantante'),
					1=> array('testimonio'=> 'Logré bajar de peso, aunque disminuí mucho más de medidas. Logré sentirme más fuerte en general, más ágil y logré comprometerme conmigo misma a cumplir mis metas. En general, me siento mucho mejor conmigo misma.',
										'foto'=> 'assets/images/person_1.jpg',
										'nombre'=> 'Julieta Estrada',
										'ocupacion'=> 'Maestra de ciclo inicial'),					
					2=> array('testimonio'=> 'baje 10 kilos, y la ropa que usaba cuando tenia 20 me queda perfecta',
										'foto'=> 'assets/images/person_3.jpg',
										'nombre'=> 'Jolene Nicole Jones',
										'ocupacion'=> 'Ama de casa'),
					3=> array('testimonio'=> 'En dos meses sentí una notoria mejoría. El dolor disminuyó y al cabo de ese tiempo regresé con más fuerza y estabilidad a correr.',
										'foto'=> 'assets/images/person_4.jpg',
										'nombre'=> 'Denisse Palma',
										'ocupacion'=> 'Escritora'),										

					));
			    $datos_coaches = array('entrenadores'=> array(
				0=> array('nombre'=> 'Liliana Rodriguez',
									 'descripcion_breve'=> 'Propietaria e Instructora · Desde el 29 de enero de 2012 hasta la fecha. Egresada de Instituto Superior de Educacion Fisica Corrientes
									 De 7 mar. 2000 a 2004.',
									 'twitter_url'=> '#',	
									 'facebook_url' => 'https://www.facebook.com/profile.php?id=100011440031647',
									 'instagram_url'=> 'https://www.instagram.com/enforma__gym/',
									'tipo_de_couch'=> 'Propietario / Entrenador',
									'foto'=> 'assets/images/jefa.jpg'),
				
				2=> array('nombre'=> 'Roxana Arce',
									'descripcion_breve'=> 'Estudiante de Educación fisica y Jugadora profesional de Jockey',
									'twitter_url'=> '#',
									'facebook_url' => '#',
									'instagram_url'=> '#',
									'tipo_de_couch'=> 'Profesora de GAP y funcional',
									'foto'=> 'assets/images/Roxana_arce.jpg'),
			));
			$datos_programas =array('tipos_clases' => array(
				
				1=> array(
					'nombre' => 'Aerobic',
					'descripcion'=> 'Aeróbic o aerobic​ es un tipo de gimnasia que se realiza al son de la música, en un salón o al aire libre. El aeróbic reúne todos los beneficios del ejercicio aeróbico, además de...',
					'foto'=> 'assets/images/program-1.jpg',
					'link'=>'#'
				),
				2=> array(
					'nombre' => 'levantamiento de pesas',
					'descripcion'=> 'Es obvio que cualquier ejercicio de fuerza te va a ayudar a crear más masa muscular y la Halterofilia no iba a ser menos. Al hacer Halterofilia y no solo arrancadas y Dos Tiempos- estamos...',
					'foto'=> 'assets/images/bg_4.jpg',
					'link'=>'#'
				),
				3=> array(
					'nombre' => 'Ejercicios localizados',
					'descripcion'=> 'El sistema de entrenamiento GAP, hace referencia a un conjunto de ejercicios destinados a trabajar glúteos, abdominales y piernas. ',
					'foto'=> 'assets/images/image_5.jpg',
					'link'=>'#'
				),
							

			));
			$datos_cita=array('url_img'=>'assets/images/about-3.jpg)');
			$datos_price =array('precios'=> array(
				0=> array('nombre'=> 'Entrenamiento de un día',
									'precio' => '100',
									'texto_breve'=>'Acceso sin limites a todo por 24 hs',
									'url_empezar'=> '#',
									'subtitulo'=> 'Disfruta de todas las características',
									'item' => array('Acceso unico a todo el gimnasio',
																	 'Entrenador de grupo',
																	 'Reservar una clase de grupo',
																	 'Orientación de Fitness'
													),

						),
				1=> array('nombre'=> 'Pagar cuota mensual',
									'precio' => '600',
									'texto_breve'=>'Todas las características están incluidas.',
									'url_empezar'=> '#',
									'subtitulo'=> 'Disfruta de todas las características',
									'item' => array('Clases grupales',
																	 'Discutir objetivos de fitness',
																	 'Entrenador de grupo',
																	 'Orientación de Fitness'
																	),
									


						),
				2=> array('nombre'=> 'Pagar cuota anualmente',
									'precio' => '6000',
									'texto_breve'=>'Todas las características están incluidas.',
									'url_empezar'=> '#',
									'subtitulo'=> 'Disfruta de todas las características',
									'item' => array('Clases grupales',
																	 'Discutir objetivos de fitness',
																	 'Entrenador de grupo',
																	 'Orientación de Fitness'
																	),
			


							),
				

			));
			$datos_contenido['datos_contenido']=array(
			//  'propositos_web' => $propositos_web, 	
			'galeria_instagram'=>array(
										0=>array('url_imagen'=> 'assets/images/gallery-1.jpg'),
										1=>array('url_imagen'=> 'assets/images/gallery-2.jpg'),
										2=>array('url_imagen'=> 'assets/images/gallery-3.jpg'),
										3=>array('url_imagen'=> 'assets/images/gallery-4.jpg'),
										4=>array('url_imagen'=> 'assets/images/gallery-5.jpg'),
										5=>array('url_imagen'=> 'assets/images/gallery-6.jpg'),
										6=>array('url_imagen'=> 'assets/images/gallery-7.jpg'),
										7=>array('url_imagen'=> 'assets/images/gallery-8.jpg'),
										
										
										),
			
			'blogsrecientes'=> $datos_blogrecientes,
			);
			


		$datos = array('titulo' => $titulo, 'pagina' => $a);
		$datos_head =array('titulo' => $titulo, 'pagina' => $a, 'url_css' => array(
			"assets/css/btncircular.css",
			"assets/css/open-iconic-bootstrap.min.css",
			"assets/css/animate.css",
			"https://fonts.googleapis.com/css?family=Barlow+Semi+Condensed:100,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" ,
			"assets/css/owl.carousel.min.css",
			"assets/css/owl.theme.default.min.css",
			"assets/css/magnific-popup.css",
			"assets/css/aos.css",
			"assets/css/ionicons.min.css",
			"assets/css/font-awesome.min.css",
			"assets/css/bootstrap-datepicker.css",
			"assets/css/jquery.timepicker.css",
			"assets/css/flaticon.css",
			"assets/css/icomoon.css",
			"assets/css/style.css",
			

		));
		
		$datos_header= array(
			'empresa' => 'En forma gym',
			'menu'=> array(
				0=> array(
					'nombre' => 'Principal',
					'url' => 'index',
			
				),
				1=> array(
					'nombre'=> 'Programa',
					'url'=> 'program',
				),
				2=> array(
					'nombre'=> 'Entrenadores',
					'url'=> 'coaches',
				),
				3=> array(
					'nombre'=> 'Horario',
					'url'=> 'schedule',
				),
				4=> array(
					'nombre'=> 'Acerca de',
					'url'=> 'about',
				),
				5=> array(
					'nombre'=> 'Revista',
					'url'=> 'blog',
				),
				
				6=> array(
					'nombre'=> 'Contacto',
					'url'=> 'contact',
				),
			
			),
			'datosheader'=> array(
			0=> array('pagina'=> 'program', 
					  'seccionA'=> "Principal",
					  'seccionB'=>"Programa", 
					  'subtitulo' => "Tipos de rutinas de gimnasio",
					  'imagen'=> "assets/images/bg_2.jpg",
					 
		 	),
		    1=> array('pagina'=> 'coaches', 
						'seccionA'=> "Principal",
						'seccionB'=>"Entrenadores", 
						'subtitulo' => "Profesoras de Gimnasia",
						'imagen'=> "assets/images/bg_2.jpg",
						
			
			),
			2=> array('pagina'=> 'schedule', 
						'seccionA'=> "Principal",
						'seccionB'=>"horario",
						'subtitulo' =>"horario de clase",
						'imagen'=>"assets/images/bg_2.jpg",
			
			
			),
			3=> array('pagina'=> 'about',
						'seccionA'=> "Principal",
						'seccionB'=>"sobre nosotros",
						'subtitulo' =>"Sobre nosotros",
						'imagen'=>"assets/images/bg_2.jpg",
						
			
			
			),
			4=> array('pagina'=> 'blog',
						'seccionA'=> "Principal",
						'seccionB'=>"blog",
						'subtitulo' => "Nuestra revista",
						'imagen'=>"assets/images/bg_2.jpg",
						
						
			
			),
			5=> array('pagina'=> 'blog-single',
						'seccionA'=> "Principal",
						'seccionB'=>"noticias breves",
						'subtitulo' =>"Noticias breves",
						'imagen'=>"assets/images/bg_2.jpg",
						
						
						
			
			),
			6=> array('pagina'=> 'contact',
						'seccionA'=> "Principal",
						'seccionB'=>"Contacto", 
						'subtitulo' =>"Contáctenos",
						'imagen'=>"assets/images/bg_2.jpg",

						
			
			),
			7=> array('pagina'=> 'index',
			          'datocarrousel'=> array(
						0 => array(
							'img'=> 'assets/images/bg_1.jpg',
							'titulo'=> 'Obtener un cuerpo fitness',
							'subtitulo'=>'Se uno de nosotros',),
				         1=> array(
							 'img'=> 'assets/images/bg_2.jpg',
							 'titulo'=> 'Alcanza tus metas',
							 'subtitulo'=>'Pon tu cuerpo en forma',)
					  ),

						
			
			),
		
		), $datos); 
       
		
			
				
		// echo var_dump($datosheader['datosheader']);	
		
       	$this->load->view('templates/head', $datos_head);
	   
		 $this->load->view('templates/header', $datos_header);
	   switch ($a) {
		   case 'index':
				   $this->load->view('contents/section_services', $datos_section_services);
				   $this->load->view('contents/section_counter', $datos_section_counter);  
				   $this->load->view('contents/section_about', $datos_section_about);
				   $this->load->view('contents/section_coaches', $datos_coaches);
				   $this->load->view('contents/'.$a, $datos_contenido); 
				   $this->load->view('contents/section_testimony', $datos_testimony);
					 $this->load->view('contents/section_program', $datos_programas);	
					//  $this->load->view('contents/section_price', $datos_price);
					
					$this->load->view('contents/section_appoitment', $datos_cita);

			   break;
			// case "blog":
			// 	$this->load->view('contents/section_blogs', $datos_blogs);
			// break;
			case "program":
				$this->load->view('contents/section_program', $datos_programas);
				break;
			 case 'about':
				 $this->load->view('contents/section_services', $datos_section_services); 
				 $this->load->view('contents/section_counter', $datos_section_counter);
				 $this->load->view('contents/section_about', $datos_section_about);	
				 $this->load->view('contents/section_coaches', $datos_coaches);
				 $this->load->view('contents/section_testimony', $datos_testimony);
			   break;
			case 'coaches':
				$this->load->view('contents/section_coaches', $datos_coaches);
				break;   
				
				default:
					$this->load->view('contents/'.$a, $datos_contenido); 
					break;
			
		   
	   }
		 
     	$this->load->view('templates/footer', $datosfooter);

	}
}

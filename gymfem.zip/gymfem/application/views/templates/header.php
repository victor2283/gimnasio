<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>  	<nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">

<div class="container">
	<a class="navbar-brand py-1 px-1" href="index"><?Php echo $empresa; ?></a>
	<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
		<span class="oi oi-menu"> <br><br></span> Menu
	</button>
	<div class="collapse navbar-collapse" id="ftco-nav">
	
			
	<ul class="navbar-nav ml-auto">
		<?Php 
			$blog='0';
			foreach ($menu as $menuitem) {
				
			?>
			
			<li class="nav-item  <?Php if($menuitem['url']==$pagina){echo "active";}else{echo " ";} ?>"><a href="<?Php echo $menuitem['url']?>" class="nav-link"><?Php echo $menuitem['nombre']?></a></li>  
			
				<?Php
			}
			
	

?>


	        </ul>
	      </div>
		  </div>
	  </nav>
    <?Php
	  switch ($pagina) {
		case 'index':?>
		
		
			<section class="home-slider  js-fullheight owl-carousel ftco-degree-bottom">
					
					<?Php 
						// echo var_dump($datosheader);
						foreach ($datosheader[7]['datocarrousel'] as $articulo) {
						?>
				
								<div class="slider-item js-fullheight"   style="background-image: url(<?Php echo $articulo['img'];?>);">
										<div class="overlay"> </div>
										<div class="container">
											<div class="row slider-text js-fullheight justify-content-center align-items-center" data-scrollax-parent="true">
								
												<div class="col-sm-11 ftco-animate text-center ">
														<h1 class="mb-2"><?Php echo $articulo['titulo'];?></h1>
														<h2 class="subheading"><?Php echo $articulo['subtitulo'];?></h2>
															
															<div class="col-12">
																<hr><br>
											<a href="#" class="mouse-icon" > 
																	<div class="mouse-wheel">
																	 <span class="flecha ion-ios-arrow-down"  > </span>
																	 
																	
																	
																	</div>
																</a>
																
															</div>
															
														
												</div>
												
											</div>
										</div>
										
								</div>
								
								
								
								
								<?Php
						
						
						}?>
			
			</section> 		
			
		
		
		
	
		<?Php
			# code...
			break;
		
			default:
			$seccionA= "";
			$seccionB=""; 
			$subtitulo ="";
			$imagen="";
		foreach ($datosheader as $datoweb) {
		if ($pagina==$datoweb['pagina']){
			$seccionA= $datoweb['seccionA'];
			$seccionB=$datoweb['seccionB']; 
			$subtitulo =$datoweb['subtitulo'];
			$imagen=$datoweb['imagen'];
		}
			// echo '<h1 class ="lead">'.$datoweb['pagina'].'<br>';
		}


				?>
			
		  <!-- ***** Breadcrumb Area Start ***** -->
		<div class="hero-wrap" style="height: 350px; position: relative;
									z-index: 1; background-position:center;
									background-size: cover;
									background-repeat: no-repeat; background-image: url(<?Php echo $imagen;?>);">
			<!-- <div class="overlay"></div> -->
			<div class="container h-100">
				<div class="row h-100 align-items-center">
					<div class="col-12">
						<h2 class="col-xs-11 ftco-animate text-center" style="color: #ffff; font-size:50px;  font-weight:800; position:relative; text-transform:uppercase;
														line-height:1.2; letter-spacing:1px; font-style:italic;"><?Php echo $subtitulo; ?></h2>
					</div>
				</div>
			</div>
		</div>
		<div class="breadcumb--con">
			<div class="container">
				<div class="row">
					<div class="col-12">
						<nav aria-label="breadcrumb">
							<ol class="breadcrumb">
								<li class="breadcrumb-item" style="text-transform: uppercase;"><a href="#"><i class="fa fa-home"></i> <?Php echo $seccionA;?></a></li>
								<li class="breadcrumb-item active" aria-current="page" style="text-transform: uppercase;"> <?Php echo $seccionB; ?></li>
							</ol>
						</nav>
					</div>
				</div>
			</div>
		</div>
		
		<div class ="row"><hr> </div> 
		<!-- ***** Breadcrumb Area End ***** -->
			<?Php 
			break;
			
		
	}
	?> 	
	  
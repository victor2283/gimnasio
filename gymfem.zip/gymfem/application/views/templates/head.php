<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
  <head>
  
  <title><?= $titulo ?> </title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  
    <?Php  
  foreach ($url_css as $dato_css) {
    ?> <link rel="stylesheet" href="<?Php echo $dato_css; ?>"><?Php
    
  }
  ?>  
    
    
  </head>
  <body>

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

?>
    
    <footer class="ftco-footer ftco-section img">
    	<div class="overlay"></div>
      <div class="container">
        <div class="row mb-5">
          <div class="col-lg-3 col-md-6 mb-5 mb-md-5">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2"><?Php echo $about_us['titulo'];?></h2>
              <p><?Php echo $about_us['descripcion'];?></p>
              <ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-5">
              <?Php
              foreach ($contacto as $contacto_dato) {
                ?><li class="ftco-animate"><a href="<?Php echo $contacto_dato['url']; if($contacto_dato['url']=="#"){echo 'onclick="return false;"';}?>"><span class="<?Php echo $contacto_dato['icon']; ?>"></span></a></li> <?Php 
              }
              ?>    
              
              </ul>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 mb-5 mb-md-5">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">blogs reicientes</h2>
              <?Php 
              
               $co=1;
               
               foreach ($blogsrecientes as $dato_blog) {
                 if($co>2){
                   // echo "dos blogs"; 
                    break; 
                   
                  }else{
                    // echo 'blog nro ='.$co++."<br>";

                     ?>
                        <div class="block-21 mb-4 d-flex">
                          <a class="blog-img mr-4" style="background-image: url(<?Php echo $dato_blog['foto_url']?>"></a>
                          <div class="text">
                            <h3 class="heading"><a href="#"><?Php echo $dato_blog['titulo_art']?></a></h3>
                            <div class="meta">
                              <div><a href="#"><span class="<?Php echo $dato_blog['fecha_publicacion']['icon']?>"></span> <?Php echo $dato_blog['fecha_publicacion']['fecha']?></a></div>
                              <div><a href="#"><span class="<?Php echo $dato_blog['publicado_por']['icon']?>"></span> <?Php echo $dato_blog['publicado_por']['usuario']?></a></div>
                              <div><a href="#"><span class="<?Php echo $dato_blog['num_comentarios']['icon']?>"></span> <?Php echo $dato_blog['num_comentarios']['cantidad']?></a></div>
                            </div>
                          </div>
                        </div>

                    <?Php $co++;
                 }
               } 
                ?>
              
            </div>
          </div>
          <div class="col-lg-2 col-md-6 mb-5 mb-md-5">
             <div class="ftco-footer-widget mb-4 ml-md-4">
              <h2 class="ftco-heading-2"><?Php echo $servicios['titulo'];?></h2>
              <ul class="list-unstyled">
              <?Php 
              foreach ($servicios['items'] as $servicio_item) {
                ?><li><a href="#" class="py-2 d-block"><?Php echo $servicio_item;?></a></li><?Php
              }
              ?>  
              
                
              </ul>
            </div>
          </div>
          <div class="col-lg-3 col-md-6 mb-5 mb-md-5">
            <div class="ftco-footer-widget mb-4">
            	<h2 class="ftco-heading-2"><?Php echo $consultas['titulo'];?></h2>
            	<div class="block-23 mb-3">
	              <ul>
                <?Php 
                foreach ($consultas['listado'] as $dato_consulta) {
                  ?><li><span class="icon <?Php echo $dato_consulta['icon'];?>"></span><span class="text"><?Php echo $dato_consulta['dato_mostrar']; ?> </span></li><?Php
                }
                ?> 
                
	                
	              </ul>
	            </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12 text-center">

            <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
  Copyright &copy;<script>document.write(new Date().getFullYear());</script> Todos los derechos reservados | Esta plantilla está hecha con <i class="icon-heart" aria-hidden="true"></i> por <a href="<?Php echo $autor['url'];?>" target="_blank"><?Php echo $autor['nombre'];?></a>
  
  <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
          </div>
        </div>
      </div>
    </footer>
    
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen">
     <svg class="circular" width="48px" height="48px">
       <circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/>
       <circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/>
      </svg>
  </div>

<?Php 
foreach ($dato_script as $url_script) {
  ?>
    <script src="<?Php echo $url_script;?>"></script>
  <?Php
}
?>

			    
                                
           
          
<a class ="ir-arriba">  
  <div class="mouse-wheel">
    <i class="ion-ios-arrow-up"> </i>
	</div>
</a>

          
																	 
																	 
																	
																	
																	

  </body>
</html>
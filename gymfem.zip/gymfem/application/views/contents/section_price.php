<section class="ftco-section bg-light">
      <div class="container">
        <div class="row justify-content-center mb-5 pb-3">
          <div class="col-md-7 heading-section ftco-animate text-center">
            <h3 class="subheading">Tablas de Precios</h3>
            <h2 class="mb-1">Planes para socios</h2>
          </div>
        </div>
        <div class="row">
				<?Php
				foreach ($precios as $dato_precio){
				?>
						<div class="col-md-4 ftco-animate">
	            <div class="block-7">
	              <div class="text-center">
							    <h2 class="heading"><?Php echo $dato_precio['nombre']; ?></h2>
									<span class="price"><sup>$Arg.</sup> <span class="number"><?Php echo $dato_precio['precio']; ?></span></span>
									<span class="excerpt d-block"><?Php echo $dato_precio['texto_breve']; ?></span>
									<a href="<?Php echo $dato_precio['url_empezar']; ?>" class="btn btn-primary d-block px-2 py-4 mb-4">Empezar</a>
									<h3 class="heading-2 mb-4"><?Php echo $dato_precio['subtitulo']; ?></h3>
									<ul class="pricing-text">
									<?Php 
									foreach ($dato_precio['item'] as $valor) {
										echo  '<li>'.$valor.'</li>';
									}
									?>
									
									</ul>
	            </div>
						</div>
						</div>
	      <?Php  
				}
				?>	
		  </div>
    </section>
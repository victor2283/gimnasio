<section class="ftco-section testimony-section">
      <div class="container">
        <div class="row justify-content-center mb-5 pb-3">
          <div class="col-md-7 heading-section ftco-animate text-center">
            <h3 class="subheading">Testimonio</h3>
            <h2 class="mb-1">Historias exitosas</h2>
          </div>
        </div>
        <div class="row ftco-animate">
          <div class="col-md-12">
            <div class="carousel-testimony owl-carousel">
						 
						<?Php
								foreach ($exito_testimonio as $dato_testimonio){
								?> 


						<div class="item">
                <div class="testimony-wrap p-4 pb-5">
                  <div class="text">
                    <p class="mb-4 pb-1 pl-4 line"><?Php echo $dato_testimonio['testimonio']; ?></p>

                    <div class="d-flex align-items-center">
                    	<div class="user-img" style="background-image: url(<?Php echo $dato_testimonio['foto']; ?>)">
		                    <span class="quote d-flex align-items-center justify-content-center">
		                      <i class="icon-quote-left"></i>
		                    </span>
		                  </div>
		                  <div class="ml-4">
		                  	<p class="name"><?Php echo $dato_testimonio['nombre']; ?></p>
		                    <span class="position"><?Php echo $dato_testimonio['ocupacion']; ?></span>
		                  </div>
                    </div>
                  </div>
                </div>
              </div>

								<?Php
								
								}
						?>
					
              
              
            </div>
          </div>
        </div>
      </div>
    </section>
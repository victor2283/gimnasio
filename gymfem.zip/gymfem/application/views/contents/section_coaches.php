<section class="ftco-section bg-light">
    	<div class="container-fluid">
    		<div class="row justify-content-center mb-5">
          <div class="col-md-7 heading-section text-center ftco-animate">
          	<h3 class="subheading">Da forma a tu cuerpo</h3>
            <h2 class="mb-1">Nuestros entrenadores</h2>
          </div>
        </div>
    		<div class="row">
			<?Php 
			foreach ($entrenadores as $dato_couch) {
			?>
				<div class="col-lg-3 d-flex border">
    				<div class="coach align-items-stretch">
						<div class="" alt=""  style="background-image: url();"> <img class="img-fluid" src="<?Php echo $dato_couch['foto']; ?>" alt="Chania"> </div>
						<div class="text bg-white p-4 ftco-animate ">
	    					<span class="subheading"><?Php echo $dato_couch['tipo_de_couch']; ?></span>
	    					<h3><a href="#"><?Php echo $dato_couch['nombre']; ?> </a></h3>
	    					<p><?Php echo $dato_couch['descripcion_breve']; ?></p>
	    					<ul class="ftco-social-media d-flex mt-4">
	                <li class="ftco-animate"><a href="<?Php echo $dato_couch['twitter_url']; ?>" class="mr-2 d-flex justify-content-center align-items-center"><span class="icon-twitter"></span></a></li>
	                <li class="ftco-animate"><a href="<?Php echo $dato_couch['facebook_url']; ?>" class="mr-2 d-flex justify-content-center align-items-center"><span class="icon-facebook"></span></a></li>
	                <li class="ftco-animate"><a href="<?Php echo $dato_couch['instagram_url']; ?>" class="mr-2 d-flex justify-content-center align-items-center"><span class="icon-instagram"></span></a></li>
	              </ul>
	    					<p></p>
	    				</div>
	    			</div>
    			</div>
		<?Php
			
			}
			?>
				    			
    	</div>
    </section>
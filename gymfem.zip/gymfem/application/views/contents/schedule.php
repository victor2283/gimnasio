 
	 
    <section class="ftco-section">
			<div class="container">
				<div class="row">
    			<div class="col-md-12 ftco-animate">
    				<div class="sched-list table-responsive">
	    				<table class="table">
						    <thead class="thead-primary">
						      <tr class="text-center">
						        <th>&nbsp;</th>
						        <th>Lunes</th>
						        <th>Martes</th>
						        <th>Miercoles</th>
						        <th>Jueves</th>
						        <th>Viernes</th>
						        
						      </tr>
						    </thead>
						    <tbody>
						      <tr class="text-center">
						        <td class="color">
						        	<p class="time">14:00 hs</p>
						        </td>
						        
						        <td class="color-3">
						        	<h3><a href="#">Clase de Funcional</a></h3>
						        	<span class="at"> </span>
						        	<p class="time">14:00 hs - 15:00 hs</p>
						        	
						        </td>
						        
						        <td class="color-3">
						        	<h3><a href="#">Clase de Funcional</a></h3>
						        	<span class="at"> </span>
						        	<p class="time">14:00 hs - 15:00 hs</p>
						        	
						        </td>
						        
						        <td class="color-3">
						        	<h3><a href="#">Clase de Funcional</a></h3>
						        	<span class="at"> </span>
						        	<p class="time">14:00 hs - 15:00 hs</p>
						        	
						        </td>
						        
						        <td class="color-3">
						        	<h3><a href="#">Clase de Funcional</a></h3>
						        	<span class="at"> </span>
						        	<p class="time">14:00 hs - 15:00 hs</p>
						        	
						        </td>
						        
						        <td class="color-3">
						        	<h3><a href="#">Clase de Funcional</a></h3>
						        	<span class="at"> </span>
						        	<p class="time">14:00 hs - 15:00 hs</p>
						        	
						        </td>

						        
						      </tr><!-- END TR-->

						      <tr class="text-center">
						        <td class="color">
						        	<p class="time"></p>
						        </td>
						        
						        <td class="color-2">
						        	<h3><a href="#">GAP</a></h3>
						        	<span class="at"> </span>
						        	<p class="time">15:00 hs - 16:00hs</p>
						        	
						        </td>
						        
										<td class="color-2">
						        	<h3><a href="#">GAP</a></h3>
						        	<span class="at"> </span>
						        	<p class="time">15:00 hs - 16:00hs</p>
						        	
						        </td>
						        
										<td class="color-2">
						        	<h3><a href="#">GAP</a></h3>
						        	<span class="at"> </span>
						        	<p class="time">15:00 hs - 16:00hs</p>
						        	
						        </td>
						        
										<td class="color-2">
						        	<h3><a href="#">GAP</a></h3>
						        	<span class="at"> </span>
						        	<p class="time">15:00 hs - 16:00hs</p>
						        	
						        </td>
						        
										<td class="color-2">
						        	<h3><a href="#">GAP</a></h3>
						        	<span class="at"> </span>
						        	<p class="time">15:00 hs - 16:00hs</p>
						        	
						        </td>

						        
						      </tr><!-- END TR-->

						      <tr class="text-center">
						        <td class="color">
						        	<p class="time"></p>
						        </td>
						        
						        <td class="color-3">
						        	<h3><a href="#">Funcional</a></h3>
						        	<span class="at"> </span>
						        	<p class="time">16:00 hs - 17:00 hs</p>
						        	
						        </td>
						        
						        <td class="color-3">
						        	<h3><a href="#">Funcional</a></h3>
						        	<span class="at"> </span>
						        	<p class="time">16:00 hs - 17:00 hs</p>
						        	
						        </td>
						        
						        <td class="color-3">
						        	<h3><a href="#">Funcional</a></h3>
						        	<span class="at"> </span>
						        	<p class="time">16:00 hs - 17:00 hs</p>
						        	
						        </td>
						        
						        <td class="color-3">
						        	<h3><a href="#">Funcional</a></h3>
						        	<span class="at"> </span>
						        	<p class="time">16:00 hs - 17:00 hs</p>
						        	
						        </td>
						        
						        <td class="color-3">
						        	<h3><a href="#">Funcional</a></h3>
						        	<span class="at"> </span>
						        	<p class="time">16:00 hs - 17:00 hs</p>
						        	
						        </td>

						        
						      </tr><!-- END TR-->
									<tr class="text-center">
						        <td class="color">
						        	<p class="time"></p>
						        </td>
						        
						        <td class="color-5">
						        	<h3><a href="#">brazos y abdominales</a></h3>
						        	<span class="at"> </span>
						        	<p class="time">17:00 hs - 18:00 hs</p>
						        	
						        </td>
						        
						        <td class="color-5">
						        	<h3><a href="#">brazos y abdominales</a></h3>
						        	<span class="at"> </span>
						        	<p class="time">17:00 hs - 18:00 hs</p>
						        	
						        </td>
						        
						        <td class="color-5">
						        	<h3><a href="#">brazos y abdominales</a></h3>
						        	<span class="at"> </span>
						        	<p class="time">17:00 hs - 18:00 hs</p>
						        	
						        </td>
						        
						        <td class="color-5">
						        	<h3><a href="#">brazos y abdominales</a></h3>
						        	<span class="at"> </span>
						        	<p class="time">17:00 hs - 18:00 hs</p>
						        	
						        </td>
						        
						        <td class="color-5">
						        	<h3><a href="#">brazos y abdominales</a></h3>
						        	<span class="at"> </span>
						        	<p class="time">17:00 hs - 18:00 hs</p>
						        	
						        </td>

						        
									</tr><!-- END TR-->
									<tr class="text-center">
						        <td class="color">
						        	<p class="time"> 18:00 hs</p>
						        </td>
						        
						        <td class="color-2">
										<h3><a href="#">GAP</a></h3>
						        	<span class="at"> </span>
						        	<p class="time">18:00 hs - 21:00 hs</p>
						        	
						        </td>
						        
						        <td class="color-2">
						        	<h3><a href="#">GAP</a></h3>
						        	<span class="at"> </span>
						        	<p class="time">18:00 hs - 21:00 hs</p>
						        	
						        </td>
						        
						        <td class="color-2">
						        	<h3><a href="#">GAP</a></h3>
						        	<span class="at"> </span>
						        	<p class="time">18:00 hs - 21:00 hs</p>
						        	
						        </td>
						        
						        <td class="color-2">
						        	<h3><a href="#">GAP</a></h3>
						        	<span class="at"> </span>
						        	<p class="time">18:00 hs - 21:00 hs</p>
						        	
						        </td>
						        
						        <td class="color-2">
						        	<h3><a href="#">GAP</a></h3>
						        	<span class="at"> </span>
						        	<p class="time">18:00 hs - 21:00 hs</p>
						        	
						        </td>

						        
									</tr><!-- END TR-->
									<tr class="text-center">
						        <td class="color">
						        	<p class="time"> </p>
						        </td>
						        
						        <td class="color-2">
						        	
						        </td>
						        
						        <td class="color-2">
						        	
						        </td>
						        
						        <td class="color-2">
						        	
						        </td>
						        
						        <td class="color-2">
						        	
						        </td>
						        
						        <td class="color-2">
						        	
						        </td>

						        
									</tr><!-- END TR-->
									<tr class="text-center">
						        <td class="color">
						        	<p class="time"> </p>
						        </td>
						        
						        <td class="color-2">
						        	
						        </td>
						        
						        <td class="color-2">
						        	
						        </td>
						        
						        <td class="color-2">
						        	
						        </td>
						        
						        <td class="color-2">
						        	
						        </td>
						        
						        <td class="color-2">
						        	
						        </td>

						        
									</tr><!-- END TR-->
									
						    </tbody>
						  </table>
					  </div>
    			</div>
    		</div>
			</div>
		</section>


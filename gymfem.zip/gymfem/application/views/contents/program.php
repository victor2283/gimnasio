    <section class="ftco-section">
	  	<div class="container-fluid">
			<div class="row">
					<?Php 
					foreach ($datos_contenido['tipos_clases'] as $dato_entrenamiento){
						?>
							<div class="col-md-6 col-lg-3 border">
								<div class="package-program ftco-animate">
									<a href="#" class="img d-flex justify-content-center align-items-center" style="background-image: url(<?Php echo $dato_entrenamiento['foto']; ?>);">
										<span>Saber más</span>
									</a>
									<div class="text mt-3">
										<h3><a href="<?Php echo $dato_entrenamiento['link']; ?>"><?Php echo $dato_entrenamiento['nombre']; ?></a></h3>
										<p><?Php echo $dato_entrenamiento['descripcion']; ?></p>
									</div>
							</div>
        	</div>
						<?Php
					}
					?>
        	
        </div>
        <div class="row mt-5">
          <div class="col text-center">
            <div class="block-27">
              <ul>
                <li><a href="#">&lt;</a></li>
                <li class="active"><span>1</span></li>
                <li><a href="#">2</a></li>
                <li><a href="#">3</a></li>
                <li><a href="#">4</a></li>
                <li><a href="#">5</a></li>
                <li><a href="#">&gt;</a></li>
              </ul>
            </div>
          </div>
        </div>
	  	</div>
	  </section>

	  <section class="ftco-appointment">
			<div class="overlay"></div>
    	<div class="container-wrap">
    		<div class="row no-gutters d-md-flex align-items-center">
    			<div class="col-md-6 d-flex align-self-stretch img" style="background-image: url(assets/images/about-3.jpg);">
    			</div>
	    		<div class="col-md-6 appointment ftco-animate">
	    			<h3 class="mb-3">Reserve una cita</h3>
	    			<form action="#" class="appointment-form">
	    				<div class="d-md-flex">
		    				<div class="form-group">
		    					<input type="text" class="form-control" placeholder="Primer nombre">
		    				</div>
		    				<div class="form-group ml-md-4">
		    					<input type="text" class="form-control" placeholder="Apellido">
		    				</div>
	    				</div>
	    				<div class="d-md-flex">
		    				<div class="form-group">
		    					<div class="input-wrap">
		            		<div class="icon"><span class="ion-md-calendar"></span></div>
		            		<input type="text" class="form-control appointment_date" placeholder="Fecha">
	            		</div>
		    				</div>
		    				<div class="form-group ml-md-4">
		    					<div class="input-wrap">
		            		<div class="icon"><span class="ion-ios-clock"></span></div>
		            		<input type="text" class="form-control appointment_time" placeholder="Hora">
	            		</div>
		    				</div>
		    				<div class="form-group ml-md-4">
		    					<input type="text" class="form-control" placeholder="Teléfono">
		    				</div>
	    				</div>
	    				<div class="d-md-flex">
	    					<div class="form-group">
		              <textarea name="" id="" cols="30" rows="2" class="form-control" placeholder="Escribe un Mensaje"></textarea>
		            </div>
		            <div class="form-group ml-md-4">
		              <input type="submit" value="Cita" class="btn btn-primary py-3 px-4">
		            </div>
	    				</div>
	    			</form>
	    		</div>    			
    		</div>
    	</div>
    </section>



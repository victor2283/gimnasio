
  

   

		<section class="ftco-section">
      <div class="container">
        <div class="row">
          <div class="col-lg-8 ftco-animate">
            <h2 class="mb-3">¿Por qué es importante hacer ejercicio?</h2>
            <p>Lo más probable es que hayas oído incontables veces que hacer ejercicio es "bueno para ti". Pero ¿sabías que, en el fondo, también te puede ayudar a sentirte bien? Hacer la cantidad adecuada de ejercicio físico puede aumentar tu nivel de energía y hasta ayudarte a mejorar el estado de ánimo.</p>
            <p>
              <img src="assets/images/image_1.jpg" alt="" class="img-fluid" alt="Responsive image">
            </p>
            <h3>Ventajas y efectos beneficiosos del ejercicio físico</h3>
            <p>
            Los expertos recomiendan que los adolescentes hagan 60 minutos o más de actividad física de moderada a vigorosa cada día. He aquí algunas de las razones:
            </p>
            
            
              <ul> 
                <li>
                El ejercicio físico es bueno para todas las partes del cuerpo, incluida la mente
                

              </li>
              <p>
                  El ejercicio físico hace que el cuerpo genere sustancias químicas que pueden ayudar a una persona a sentirse bien. El ejercicio físico puede ayudar a las personas a dormir mejor. También puede ayudar a algunas personas que padecen una depresión leve o que tienen baja autoestima. Además, el ejercicio puede dar a la gente una verdadera sensación de logro y orgullo por alcanzar determinadas metas, como batir un récord personal en 100 metros llanos.
                </P>
              <li>
              El ejercicio físico también puede ayudar a tener mejor aspecto
              </li>
              <p>La gente que hace ejercicio quema más calorías y se ve más tonificada que la que no lo hace. De hecho, el ejercicio físico puede ayudar a mantener el cuerpo en un peso saludable.</p>
              
            </ul>
            
            <p>
              <img src="assets/images/image_2.jpg" alt="" class="img-fluid" alt="Responsive image">
            </p>
            <h2>Ejercicios aeróbicos</h2>
            <p>Al igual que otros músculos, el corazón disfruta de un buen entrenamiento. Un ejercicio aeróbico es cualquier tipo de ejercicio que haga que el corazón bombee y lata más fuerte. Si proporcionas a tu corazón y tus pulmones este tipo de entrenamiento con regularidad, se harán más fuertes y serán más eficientes a la hora de llevar oxígeno (en forma de células portadoras de oxígeno) a todas las partes de tu cuerpo..</p>
            <p>Si formas parte de un equipo deportivo, lo más probable es que ya estés haciendo 60 minutos o más de ejercicio físico de moderado a vigoroso los días en que entrenas. Algunos de los deportes de equipo que proporcionan un buen entrenamiento aeróbico son , el baloncesto, el fútbol, el lacrosse, el hockey y el remo.</p>
            <p>Pero, si no practicas ningún deporte de equipo, no te preocupes; hay muchas formas de hacer ejercicio aeróbico, sea a solas o con tus amigos. Estas formas incluyen montar en bicicleta, correr, nadar, bailar, patinar, jugar al tenis, practicar esquí de fondo, el excursionismo y andar deprisa.</p>
            
            <div class="tag-widget post-tag-container mb-5 mt-5">
              <div class="tagcloud">
                <a href="#" class="tag-cloud-link">Vida</a>
                <a href="#" class="tag-cloud-link">Deporte</a>
                <a href="#" class="tag-cloud-link">Tecnología</a>
                <a href="#" class="tag-cloud-link">Viaje</a>
              </div>
            </div>
            
            <div class="about-author d-flex">
              <div class="bio align-self-md-center mr-5">
                <img src="assets/images/person_2.jpg" alt="Image placeholder" class="img-fluid mb-4" alt="Responsive image" >
              </div>
              <div class="desc align-self-md-center">
                <h3>Clarisa martinez</h3>
                <p>Me encanto el articulo, muy completo y bien explicado. Gracias ¡¡¡</p>
              </div>
            </div>


            <div class="pt-5 mt-5">
              <h3 class="mb-5">6 Comments</h3>
              <ul class="comment-list">
                <li class="comment">
                  <div class="vcard bio">
                    <img src="assets/images/person_4.jpg" class ="img-fluid" alt="Responsive image placeholder">
                  </div>
                  <div class="comment-body">
                    <h3>martina lopez</h3>
                    <div class="meta">Dec 27, 2018 at 2:21pm</div>
                    <p>Pueden publicar mas seguido que siempre leo su pagina?</p>
                    <p><a href="#" class="reply">Responder</a></p>
                  </div>
                </li>

                <li class="comment">
                  <div class="vcard bio">
                    <img src="assets/images/person_1.jpg" class ="img-fluid" alt="Responsive Image placeholder">
                  </div>
                  <div class="comment-body">
                    <h3>Angelica lizboa</h3>
                    <div class="meta">Dec 27, 2018 at 2:21pm</div>
                    <p>Cada tanto suben articulos, me encanto la nota sobre ejercicios de abdominales</p>
                    <p><a href="#" class="reply">Responder</a></p>
                  </div>

                  <ul class="children">
                    <li class="comment">
                      <div class="vcard bio">
                        <img src="assets/images/person_3.jpg" class ="img-fluid" alt="Responsive Image placeholder">
                      </div>
                      <div class="comment-body">
                        <h3>Marta Benitez</h3>
                        <div class="meta">Dec 27, 2018 at 2:21pm</div>
                        <p>Si realmente perfecto</p>
                        <p><a href="#" class="reply">Responder</a></p>
                      </div>


                      <ul class="children">
                        <li class="comment">
                          <div class="vcard bio">
                            <img src="assets/images/person_1.jpg" class ="img-fluid" alt="Responsive Image placeholder">
                          </div>
                          <div class="comment-body">
                            <h3>Angelica lizboa</h3>
                            <div class="meta">Dec 27, 2018 at 2:21pm</div>
                            <p>Totalmente de acuerdo</p>
                            <p><a href="#" class="reply">Responder</a></p>
                          </div>

                            <ul class="children">
                              <li class="comment">
                                <div class="vcard bio">
                                  <img src="assets/images/person_4.jpg" class ="img-fluid" alt="Responsive Image placeholder">
                                </div>
                                <div class="comment-body">
                                  <h3>Martina Lopez</h3>
                                  <div class="meta">Dec 27, 2018 at 2:21pm</div>
                                  <p>Tambien lee el de GAP esta bien completo</p>
                                  <p><a href="#" class="reply">Responder</a></p>
                                </div>
                              </li>
                            </ul>
                        </li>
                      </ul>
                    </li>
                  </ul>
                </li>

                <li class="comment">
                  <div class="vcard bio">
                    <img src="assets/images/person_1.jpg" class ="img-fluid" alt="Responsive Image placeholder">
                  </div>
                  <div class="comment-body">
                    <h3>Angelica lizboa</h3>
                    <div class="meta">Dec 27, 2018 at 2:21pm</div>
                    <p>Espero que siempre publiquen cosas asi, me facilito mis ejercicios</p>
                    <p><a href="#" class="reply">Responder</a></p>
                  </div>
                </li>
              </ul>
              <!-- END comment-list -->
              
              <div class="comment-form-wrap pt-5">
                <h3 class="mb-5">Deja un comentario</h3>
                <form action="#" class="bg-light p-4">
                  <div class="form-group">
                    <label for="name">Nombre *</label>
                    <input type="text" class="form-control bg-white" id="name">
                  </div>
                  <div class="form-group">
                    <label for="email">Correo electrónico *</label>
                    <input type="email" class="form-control" id="email">
                  </div>
                  <div class="form-group">
                    <label for="website">Sitio Web</label>
                    <input type="url" class="form-control" id="website">
                  </div>

                  <div class="form-group">
                    <label for="message">Mensaje</label>
                    <textarea name="" id="message" cols="30" rows="10" class="form-control"></textarea>
                  </div>
                  <div class="form-group">
                    <input type="submit" value="Publicar comentario" class="btn py-3 px-4 btn-primary">
                  </div>

                </form>
              </div>
            </div>

          </div> <!-- .col-md-8 -->
          <div class="col-lg-4 sidebar ftco-animate">
            <div class="sidebar-box">
              <form action="#" class="search-form">
                <div class="form-group">
                	<div class="icon">
	                  <span class="icon-search"></span>
	                </div>
                  <input type="text" class="form-control" placeholder="Buscar algo..">
                </div>
              </form>
            </div>
            <div class="sidebar-box ftco-animate">
              <div class="categories">
                <h3 class="heading-2">Categorias</h3>
                <li><a href="#">Rutina de ejercicio <span>(5)</span></a></li>
                <li><a href="#">Gimnasio <span>(12)</span></a></li>
                <li><a href="#">Crossfit <span>(10)</span></a></li>
                <li><a href="#">Cuerpo en forma <span>(22)</span></a></li>
                <li><a href="#">Aptitud <span>(14)</span></a></li>
                <li><a href="#">GAP<span>(13)</span></a></li>
              </div>
            </div>

            <div class="sidebar-box ftco-animate">
              <h3 class="heading-2">Blogs Recientes</h3>
              <div class="block-21 mb-4 d-flex">
                <a class="blog-img mr-4 img-fluid" alt="Responsive image" style="background-image: url(assets/images/image_1.jpg);"></a>
                <div class="text">
                  <h3 class="heading"><a href="#">Nueve señales de que se esfuerza demasiado en el gimnasio</a></h3>
                  <div class="meta">
                    <div><a href="#"><span class="icon-calendar"></span> July 12, 2018</a></div>
                    <div><a href="#"><span class="icon-person"></span> Admin</a></div>
                    <div><a href="#"><span class="icon-chat"></span> 19</a></div>
                  </div>
                </div>
              </div>
              <div class="block-21 mb-4 d-flex">
                <a class="blog-img mr-4 img-fluid" alt="Responsive image" style="background-image: url(assets/images/image_2.jpg);"></a>
                <div class="text">
                  <h3 class="heading"><a href="#">¿Cómo adelgazar en el gym? 10 preguntas a una experta en fitness</a></h3>
                  <div class="meta">
                    <div><a href="#"><span class="icon-calendar"></span> July 12, 2018</a></div>
                    <div><a href="#"><span class="icon-person"></span> Admin</a></div>
                    <div><a href="#"><span class="icon-chat"></span> 19</a></div>
                  </div>
                </div>
              </div>
              <div class="block-21 mb-4 d-flex">
                <a class="blog-img mr-4" style="background-image: url(assets/images/image_3.jpg);"></a>
                <div class="text">
                  <h3 class="heading"><a href="#">Gimnasios "24 horas": ¿es saludable entrenar durante la madrugada?</a></h3>
                  <div class="meta">
                    <div><a href="#"><span class="icon-calendar"></span> July 12, 2018</a></div>
                    <div><a href="#"><span class="icon-person"></span> Admin</a></div>
                    <div><a href="#"><span class="icon-chat"></span> 19</a></div>
                  </div>
                </div>
              </div>
            </div>
            
            <div class="sidebar-box ftco-animate">
              <h3 class="heading-2">NUBE DE ETIQUETAS</h3>
              <div class="tagcloud">
                <a href="#" class="tag-cloud-link">Plato</a>
                <a href="#" class="tag-cloud-link">menu</a>
                <a href="#" class="tag-cloud-link">Comida</a>
                <a href="#" class="tag-cloud-link">dulce</a>
                <a href="#" class="tag-cloud-link">sabrosa</a>
                <a href="#" class="tag-cloud-link">delicioso</a>
                <a href="#" class="tag-cloud-link">desierto</a>
                <a href="#" class="tag-cloud-link">bebidas</a>
              </div>
            </div>


            <div class="sidebar-box ftco-animate">
              <h3 class="heading-2">PÁRRAFO</h3>
              <p>El ejercicio físico es bueno para todas las partes del cuerpo, incluida la mente. El ejercicio físico hace que el cuerpo genere sustancias químicas que pueden ayudar a una persona a sentirse bien. El ejercicio físico puede ayudar a las personas a dormir mejor. También puede ayudar a algunas personas que padecen una depresión leve o que tienen baja autoestima. Además, el ejercicio puede dar a la gente una verdadera sensación de logro y orgullo por alcanzar determinadas metas, como batir un récord personal en 100 metros llanos.</p>
            </div>
          </div>

        </div>
      </div>
    </section> <!-- .section -->
   

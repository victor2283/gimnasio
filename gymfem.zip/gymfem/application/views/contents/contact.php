
    
		<section class="ftco-section contact-section">
      <div class="container">
        <div class="row block-9">
					<div class="col-md-4 contact-info ftco-animate bg-light p-4">
						<div class="row">
							<div class="col-md-12 mb-4">
	              <h2 class="h4">Información de contacto</h2>
	            </div>
	            <div class="col-md-12 mb-3">
	              <p><span>Dirección:</span> 	Avenida Maipú 1522 primer piso, Corrientes Capital, Argentina</p>
	            </div>
	            <div class="col-md-12 mb-3">
	              <p><span>Nº Teléfono:</span> <a href="#">+549 3794 233633</a></p>
	            </div>
	            <div class="col-md-12 mb-3">
	              <p><span>Email:</span> <a href="mailto:lilirodriguezctes22@ponerenforma.ml">enformagym_ctes@gmail.com</a></p>
	            </div>
	            <div class="col-md-12 mb-3">
	              <p><span>Website:</span> <a href="#">www.enformagymctes.ml</a></p>
	            </div>
						</div>
					</div>
					<div class="col-md-1"></div>
          <div class="col-md-6 ftco-animate">
            <form action="#" class="contact-form">
            	<div class="row">
            		<div class="col-md-6">
	                <div class="form-group">
	                  <input type="text" class="form-control" placeholder="Tu nombre">
	                </div>
                </div>
                <div class="col-md-6">
	                <div class="form-group">
	                  <input type="text" class="form-control" placeholder="Tu email">
	                </div>
	                </div>
              </div>
              <div class="form-group">
                <input type="text" class="form-control" placeholder="Asunto">
              </div>
              <div class="form-group">
                <textarea name="" id="" cols="30" rows="7" class="form-control" placeholder="Mensaje"></textarea>
              </div>
              <div class="form-group">
                <input type="submit" value="Enviar mensaje" class="btn btn-primary py-3 px-5">
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>

  <!--Google map-->
<div id="map-container" class="z-depth-1-half map-container container" style="height: 500px">
  <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d884.8150755187056!2d-58.819352!3d-27.492279000000003!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94456b82e4325271%3A0xe9cdaba02b3c6e0c!2sAv.+Maip%C3%BA+1522%2C+Corrientes!5e0!3m2!1ses-419!2sar!4v1558268716903!5m2!1ses-419!2sar" frameborder="0"
    style="border:0" allowfullscreen></iframe>
</div>
<style>.map-container{
overflow:hidden;
padding-bottom:56.25%;
position:relative;
height:0;
}
.map-container iframe{
left:0;
top:0;
height:100%;
width:100%;
position:absolute;
}</style>

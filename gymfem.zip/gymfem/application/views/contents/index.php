<section class="ftco-section bg-light">
      <div class="container">
        <div class="row justify-content-center mb-5 pb-3">
          <div class="col-md-7 heading-section ftco-animate text-center">
            <h3 class="subheading">Publicaciones</h3>
            <h2 class="mb-1">Blogs recientes</h2>
          </div>
        </div>
				<!-- ultimos 3 blog publicados en base de datos se debe guardar  -->
				<div class="row d-flex border">
				<?Php
								foreach ($datos_contenido['blogsrecientes'] as $dato_blog){
								?>
								<div class="col-md-4 d-flex ftco-animate border">
									<div class="blog-entry justify-content-end">
										<a href="blog-single" class="block-20" style="background-image: url('<?Php echo $dato_blog['foto_url']; ?>');">
										</a>
										<div class="text p-4 float-right d-block">
											<div class="meta">
												<div><a href="#"><?Php echo $dato_blog['fecha_publicacion']['fecha']; ?></a></div>
												<div><a href="#"><?Php echo $dato_blog['publicado_por']['usuario']; ?></a></div>
												<div><a href="#" class="meta-chat"><span class="icon-chat"></span> <?Php echo $dato_blog['num_comentarios']['cantidad']; ?></a></div>
											</div>
											<h3 class="heading mt-2"><a href="<?Php echo $dato_blog['url_articulo']; ?>"><?Php echo $dato_blog['titulo_art']; ?></a></h3>
											<p><?Php echo $dato_blog['descripcion_art']; ?></p>
										</div>
									</div>
								</div>
<?Php
								}
					?> 
        </div>
      </div>
 </section>


 <section class="ftco-gallery">
    	<div class="container-wrap">
    		<div class="row no-gutters">
					<div class="col-md-3 ftco-animate">
						<div class="gallery ftco-gradient d-flex justify-content-center align-items-center">
							<div class="row justify-content-center">
			          <div class="col-md-12 heading-section ftco-animate text-center">
			            <h3 class="subheading">Galería de fotos</h3>
			            <h2 class="mb-1">Instagram</h2>
			          </div>
			        </div>
		        </div>
					</div>
					<?Php
								foreach ($datos_contenido['galeria_instagram'] as $dato_galeria){
								?> 
									<div class="col-md-3 ftco-animate">
										<a href="<?Php echo $dato_galeria['url_imagen']; ?> " class="gallery image-popup img d-flex align-items-center" style="background-image: url(<?Php echo $dato_galeria['url_imagen']; ?>);">
											<div class="icon mb-4 d-flex align-items-center justify-content-center">
												<span class="icon-instagram"></span>
											</div>
										</a>
									</div>
								<?Php
								}
								?>
					
					
					
        </div>
    	</div>
    </section>

	
<section class="ftco-section">
	  	<div class="container-fluid">
	  		<div class="row justify-content-center mb-5 pb-3">
          <div class="col-md-7 heading-section ftco-animate text-center">
            <h3 class="subheading">Clases de gimnasia</h3>
            <h2 class="mb-1">Clases de entrenamiento</h2>
          </div>
        </div>
        <div class="row">
					<?Php 
					foreach ($tipos_clases as $dato_entrenamiento){
						?>
							<div class="col-md-6 col-lg-3 border">
								<div class="package-program ftco-animate">
									<a href="#" class="img d-flex justify-content-center align-items-center" style="background-image: url(<?Php echo $dato_entrenamiento['foto']; ?>);">
										<span>Saber más</span>
									</a>
									<div class="text mt-3">
										<h3><a href="<?Php echo $dato_entrenamiento['link']; ?>"><?Php echo $dato_entrenamiento['nombre']; ?></a></h3>
										<p><?Php echo $dato_entrenamiento['descripcion']; ?></p>
									</div>
							</div>
        	</div>
						<?Php
					}
					?>
        	
        </div>
	  	</div>
	  	<div class="container">
	  		<div class="row mt-4 justify-content-center ftco-animate">
        	<div class="col-md-4 text-center">
        		<a href="#" class="btn-custom py-4">Ver más programas de entrenamiento <span class="ion-ios-arrow-down ml-2"></span></a>
        	</div>
        </div>
	  	</div>
	  </section>

		<section class="ftco-section">
      <div class="container">
        <div class="row">
          <div class="col-lg-8 ftco-animate">
						<div class="row border">
						<?Php
								foreach ($datos_contenido['blogsrecientes'] as $dato_blog){
									?>


									<div class="col-md-6 d-flex ftco-animate border">
										<div class="blog-entry justify-content-end">
											<a href="blog-single" class="block-20" style="background-image: url('<?Php echo $dato_blog['foto_url']; ?>');">
											</a>
											<div class="text p-4 float-right d-block">
												<div class="meta">
													<div><a href="#"><?Php echo $dato_blog['fecha_publicacion']['fecha']; ?></a></div>
													<div><a href="#"><?Php echo $dato_blog['publicado_por']['usuario']; ?></a></div>
													<div><a href="#" class="meta-chat"><span class="icon-chat"></span> <?Php echo $dato_blog['num_comentarios']['cantidad']; ?></a></div>
												</div>
												<h3 class="heading mt-2"><a href="<?Php echo $dato_blog['url_articulo']; ?>"><?Php echo $dato_blog['titulo_art']; ?></a></h3>
												<p><?Php echo $dato_blog['descripcion_art']; ?></p>
											</div>
										</div>
									</div>
	
	<?Php
									}
						?> 
								
								
						
						
						
						</div>
						<div class="row mt-5">
		          <div class="col text-center">
		            <div class="block-27">
		              <ul>
		                <li><a href="#">&lt;</a></li>
		                <li class="active"><span>1</span></li>
		                <li><a href="#">2</a></li>
		                <li><a href="#">3</a></li>
		                <li><a href="#">4</a></li>
		                <li><a href="#">5</a></li>
		                <li><a href="#">&gt;</a></li>
		              </ul>
		            </div>
		          </div>
		        </div>
          </div> <!-- .col-md-8 -->
          <div class="col-lg-4 sidebar ftco-animate">
            <div class="sidebar-box">
              <form action="#" class="search-form">
                <div class="form-group">
                	<div class="icon">
	                  <span class="icon-search"></span>
	                </div>
                  <input type="text" class="form-control" placeholder="Buscar publicación..">
                </div>
              </form>
            </div>
            <div class="sidebar-box ftco-animate">
              <div class="categories">
                <h3 class="heading-2">Categorias</h3>
                <li><a href="#">Rutina de ejercicio <span>(12)</span></a></li>
                <li><a href="#">Gimnasio <span>(22)</span></a></li>
                <li><a href="#">Crossfit <span>(37)</span></a></li>
                <li><a href="#">Cuerpo en forma <span>(42)</span></a></li>
                <li><a href="#">Aptitud <span>(14)</span></a></li>
                <li><a href="#">GAP<span>(140)</span></a></li>
              </div>
            </div>

            <div class="sidebar-box ftco-animate">
              <h3 class="heading-2">Blogs Recientes</h3>
              <div class="block-21 mb-4 d-flex">
                <a class="blog-img mr-4" style="background-image: url(assets/images/image_1.jpg);"></a>
                <div class="text">
                  <h3 class="heading"><a href="#">Nueve señales de que se esfuerza demasiado en el gimnasio</a></h3>
                  <div class="meta">
                    <div><a href="#"><span class="icon-calendar"></span> July 12, 2018</a></div>
                    <div><a href="#"><span class="icon-person"></span> Admin</a></div>
                    <div><a href="#"><span class="icon-chat"></span> 19</a></div>
                  </div>
                </div>
              </div>
              <div class="block-21 mb-4 d-flex">
                <a class="blog-img mr-4" style="background-image: url(assets/images/image_2.jpg);"></a>
                <div class="text">
                  <h3 class="heading"><a href="#">¿Cómo adelgazar en el gym? 10 preguntas a una experta en fitness</a></h3>
                  <div class="meta">
                    <div><a href="#"><span class="icon-calendar"></span> July 12, 2018</a></div>
                    <div><a href="#"><span class="icon-person"></span> Admin</a></div>
                    <div><a href="#"><span class="icon-chat"></span> 19</a></div>
                  </div>
                </div>
              </div>
              <div class="block-21 mb-4 d-flex">
                <a class="blog-img mr-4" style="background-image: url(assets/images/image_3.jpg);"></a>
                <div class="text">
                  <h3 class="heading"><a href="#">Gimnasios "24 horas": ¿es saludable entrenar durante la madrugada?</a></h3>
                  <div class="meta">
                    <div><a href="#"><span class="icon-calendar"></span> July 12, 2018</a></div>
                    <div><a href="#"><span class="icon-person"></span> Admin</a></div>
                    <div><a href="#"><span class="icon-chat"></span> 19</a></div>
                  </div>
                </div>
              </div>
            </div>

            <div class="sidebar-box ftco-animate">
              <h3 class="heading-2">NUBE DE ETIQUETAS</h3>
              <div class="tagcloud">
                <a href="#" class="tag-cloud-link">Plato</a>
                <a href="#" class="tag-cloud-link">menu</a>
                <a href="#" class="tag-cloud-link">Comida</a>
                <a href="#" class="tag-cloud-link">dulce</a>
                <a href="#" class="tag-cloud-link">sabrosa</a>
                <a href="#" class="tag-cloud-link">delicioso</a>
                <a href="#" class="tag-cloud-link">desierto</a>
                <a href="#" class="tag-cloud-link">bebidas</a>
              </div>
            </div>

            <div class="sidebar-box ftco-animate">
              <h3 class="heading-2">PÁRRAFO</h3>
              <p>El ejercicio físico es bueno para todas las partes del cuerpo, incluida la mente. El ejercicio físico hace que el cuerpo genere sustancias químicas que pueden ayudar a una persona a sentirse bien. El ejercicio físico puede ayudar a las personas a dormir mejor. También puede ayudar a algunas personas que padecen una depresión leve o que tienen baja autoestima. Además, el ejercicio puede dar a la gente una verdadera sensación de logro y orgullo por alcanzar determinadas metas, como batir un récord personal en 100 metros llanos.</p>
            </div>
          </div>

        </div>
      </div>
    </section> <!-- .section -->
   

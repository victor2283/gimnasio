<section class="ftco-about d-md-flex bg-light">
    	<div class="one-half img" style="background-image: url(assets/images/about-2.jpg);">
    		<a href="assets/images/WhatsApp Video 2019-05-20 at 21.44.26.mp4" class="icon popup-vimeo d-flex justify-content-center align-items-center">
      		<span class="icon-play"></a>
      	</a>
    	</div>
    	<div class="one-half ftco-animate">
        <div class="heading-section ftco-animate ">
        	<h3 class="subheading">Acerca de enforma gym</h3>
          <h2 class="mb-5">Bienvenido <br>a nuestro Gym</h2>
        </div>
        <div>
  				<p>Gym enfocado a GAP, es una modalidad del fitness cuyas siglas significan Glúteos, Abdominales y Piernas. Practicar GAP sirve para fortalecer y tonificar esas tres partes del cuerpo, muy sufridas por la vida sedentaria, y que mucha gente quiere mejorar, sobre todo, las mujeres.</p>
  			</div>
    	</div>
    </section>
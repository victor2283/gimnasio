
<div class="goto-here"></div>
<section class="ftco-section-services ftco-degree ">
    	<div class="container">
    		<div class="row d-flex align-items-center">
    			<div class="col-xl-6 d-flex align-self-stretch">
    				<div class="align-self-stretch"><img src="<?Php echo $section_services['url_img'] ?> " class="img-fluid" alt=""></div>
    			</div>
    			<div class="col-xl-6 align-self-stretch pt-5">
    				<div class="row justify-content-center mb-3">
		          <div class="col-md-12 heading-section ftco-animate">
		          	<h3 class="subheading"><?Php echo $section_services['titulo'] ?></h3>
		            <h2 class="mb-4"><?Php echo $section_services['subtitulo'] ?></h2>
		          </div>
		        </div>
						<?Php
						foreach ($section_services['puntos_claves']  as $dato_puntoclave) {?>
							<div class="services d-flex ftco-animate">
							<div class="icon d-flex justify-content-center align-items-center">
								<span class="<?Php echo $dato_puntoclave['icono'];?>"></span>
							</div>
							<div class="text ml-5">
								<h3><?Php echo $dato_puntoclave['titulo'];?></h3>
								<p><?Php echo $dato_puntoclave['descripcion'];?></p>
							</div>
  					</div><?Php
						}
						
						?>
						
  					
  					</div>
    			</div>
    		</div>
    	</div>
    </section>